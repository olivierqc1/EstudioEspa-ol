
document.addEventListener("DOMContentLoaded", function () {
  const root = document.getElementById("root");
  root.innerHTML = `
    <h1>Dictée A1</h1>
    <p>Écoute la phrase et écris ce que tu entends :</p>
    <audio controls src="assets/audio/a1/dictee1.mp3"></audio>
    <br><br>
    <textarea placeholder="Écris ici..." style="width:100%; height:100px;"></textarea>
    <br><br>
    <button onclick="document.getElementById('correction').style.display='block'">Afficher la solution</button>
    <p id="correction" style="display:none; color:green;">Solution : Hola, me llamo Ana y vivo en Madrid.</p>
  `;
});
