import React from "react";
export default function A2() {
  return <div>Niveau A2 en construction...</div>;
}